#pragma once
#include "State.h"

class Settings : public State 
{
private:
    Slider                  audioSlider;
    Slider                  musicSlider;
    Checkbox                themeModern;
    Checkbox                themeClassic;
    Checkbox                themeCartoon;
    sf::Font                font;
    sf::Text                audioVolumeText;
    sf::Text                musicVolumeText;
    Button                  returnButton;
    Button*                 boardPreview[5];
    Button*                 piecePreview[5];
public:
    Settings();
    void handleInput(sf::RenderWindow& window, sf::Event event) override;
    void update(sf::RenderWindow& window) override;
    void render(sf::RenderWindow& window) override;
};