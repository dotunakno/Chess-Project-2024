#include "Board.h"
#include <sstream>

Board::Board() {
    arrowCursor.loadFromSystem(sf::Cursor::Arrow);
    handCursor.loadFromSystem(sf::Cursor::Hand);

    board.setPosition(boardX, boardY);

    oldCell.setSize(sf::Vector2f(pieceSize, pieceSize));
    oldCell.setFillColor(sf::Color(0, 0, 0, 96));

    // newCell.setSize(sf::Vector2f(pieceSize, pieceSize));
    // newCell.setFillColor(sf::Color(255, 255, 255, 128));

    frameTexture.loadFromFile("Assets/selectFrame.png");
    newCell.setTexture(frameTexture);
    newCell.setScale(
        pieceSize / newCell.getTexture()->getSize().x, 
        pieceSize / newCell.getTexture()->getSize().y
    );

    alertBox.setSize(sf::Vector2f(pieceSize, pieceSize));
    alertBox.setFillColor(sf::Color(255, 0, 0, 64));

    newestMoveBox[0].setSize(sf::Vector2f(pieceSize, pieceSize));
    newestMoveBox[0].setFillColor(sf::Color(255, 0, 0, 64));
    newestMoveBox[0].setPosition(-pieceSize, -pieceSize);

    newestMoveBox[1].setSize(sf::Vector2f(pieceSize, pieceSize));
    newestMoveBox[1].setFillColor(sf::Color(255, 0, 0, 64));
    newestMoveBox[1].setPosition(-pieceSize, -pieceSize);

    moveBuffer.loadFromFile("Sound Effects/move.mp3");
    moveSound.setBuffer(moveBuffer);

    captureBuffer.loadFromFile("Sound Effects/capture.mp3");
    captureSound.setBuffer(captureBuffer);

    castleBuffer.loadFromFile("Sound Effects/castle.mp3");
    castleSound.setBuffer(castleBuffer);

    checkBuffer.loadFromFile("Sound Effects/check.mp3");
    checkSound.setBuffer(checkBuffer);

    border.setSize(sf::Vector2f(boardSize, boardSize));
    border.setPosition(boardX, boardY); 
    border.setFillColor(sf::Color::Transparent); 
    border.setOutlineColor(sf::Color::Black); 
    border.setOutlineThickness(2.f);

    font.loadFromFile("Fonts/NotoSans.ttf");

    for (int i = 0; i < 8; i++)
    {
        columnIndex[i].setFont(font);
        columnIndex[i].setString(char('a' + i));
        columnIndex[i].setCharacterSize(12);
        columnIndex[i].setPosition(
            boardX + pieceSize * i - columnIndex[i].getLocalBounds().left + 3,
            boardY + pieceSize * 8 - columnIndex[i].getLocalBounds().height - columnIndex[i].getLocalBounds().top - 3
        );

        rowIndex[i].setFont(font);
        rowIndex[i].setString(std::to_string(8 - i));
        rowIndex[i].setCharacterSize(12);
        rowIndex[i].setPosition(
            boardX + pieceSize * 8 - rowIndex[i].getLocalBounds().width - rowIndex[i].getLocalBounds().left - 3,
            boardY + pieceSize * i - rowIndex[i].getLocalBounds().top + 3
        );
    }

    screenShot.create(screenWidth, screenHeight);
};

void Board::resetGame()
{
    if (gl::isFlipped) 
    {
        gl::WHITE = 0;
        gl::BLACK = 1;
        flip();
    }

    turn = clickCount = 0;
    oldX = oldY = -1;

    kingPos[0] = sf::Vector2i(4, 7);
    kingPos[1] = sf::Vector2i(4, 0);

    capturedPieces[0].clear();
    capturedPieces[1].clear();

    while (!history.empty()) history.pop();
    while (!unHistory.empty()) unHistory.pop();

    grid.clear();
    grid.resize(8, std::vector<std::shared_ptr<Piece> >(8, nullptr));

    //PAWN
    grid[0][1] = std::make_shared<Pawn>(gl::BLACK);
    grid[1][1] = std::make_shared<Pawn>(gl::BLACK);
    grid[2][1] = std::make_shared<Pawn>(gl::BLACK);
    grid[3][1] = std::make_shared<Pawn>(gl::BLACK);
    grid[4][1] = std::make_shared<Pawn>(gl::BLACK);
    grid[5][1] = std::make_shared<Pawn>(gl::BLACK);
    grid[6][1] = std::make_shared<Pawn>(gl::BLACK);
    grid[7][1] = std::make_shared<Pawn>(gl::BLACK);
    grid[0][6] = std::make_shared<Pawn>(gl::WHITE);
    grid[1][6] = std::make_shared<Pawn>(gl::WHITE);
    grid[2][6] = std::make_shared<Pawn>(gl::WHITE);
    grid[3][6] = std::make_shared<Pawn>(gl::WHITE);
    grid[4][6] = std::make_shared<Pawn>(gl::WHITE);
    grid[5][6] = std::make_shared<Pawn>(gl::WHITE);
    grid[6][6] = std::make_shared<Pawn>(gl::WHITE);
    grid[7][6] = std::make_shared<Pawn>(gl::WHITE);

    //KNIGHT
    grid[6][0] = std::make_shared<Knight>(gl::BLACK);
    grid[1][0] = std::make_shared<Knight>(gl::BLACK);
    grid[1][7] = std::make_shared<Knight>(gl::WHITE);
    grid[6][7] = std::make_shared<Knight>(gl::WHITE);

    //BISHOP
    grid[2][0] = std::make_shared<Bishop>(gl::BLACK);
    grid[5][0] = std::make_shared<Bishop>(gl::BLACK);
    grid[2][7] = std::make_shared<Bishop>(gl::WHITE);
    grid[5][7] = std::make_shared<Bishop>(gl::WHITE);

    //ROOK
    grid[0][0] = std::make_shared<Rook>(gl::BLACK);
    grid[7][0] = std::make_shared<Rook>(gl::BLACK);
    grid[0][7] = std::make_shared<Rook>(gl::WHITE);
    grid[7][7] = std::make_shared<Rook>(gl::WHITE);

    //QUEEN
    grid[3][0] = std::make_shared<Queen>(gl::BLACK);
    grid[3][7] = std::make_shared<Queen>(gl::WHITE);

    //KING
    grid[4][0] = std::make_shared<King>(gl::BLACK);
    grid[4][7] = std::make_shared<King>(gl::WHITE);

    newestMoveBox[0].setPosition(-pieceSize, -pieceSize);
    newestMoveBox[1].setPosition(-pieceSize, -pieceSize);

    if (gl::isFlipped) 
    {
        gl::WHITE = 1;
        gl::BLACK = 0;
        flip();
    }
}

void Board::handleInput(sf::RenderWindow& window, sf::Event event)
{
    newX = (sf::Mouse::getPosition(window).x - boardX) / pieceSize;
    newY = (sf::Mouse::getPosition(window).y - boardY) / pieceSize;

    // Set handcursor
    if (newX < 0 || newX > 7 || newY < 0 || newY > 7) newX = -1;

    // Handle click
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (clickCount)
        {
            clickCount = 0; 
            grid[oldX][oldY]->isSelected = 0;
            if (makeMove(oldX, oldY, newX, newY)) turn = !turn;
            oldX = -1;
            oldY = -1;
            validMoves.clear();
        }
        else 
        {
            if (newX != -1 && grid[newX][newY] && grid[newX][newY]->side == turn) 
            {
                clickCount = 1;
                grid[newX][newY]->isSelected = 1;
                oldX = newX;
                oldY = newY;

                // SHOW VALID MOVES
                for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) if (lastCheck(oldX, oldY, i, j))
                {
                    sf::CircleShape newMove(radius);
                    newMove.setPosition(boardX + pieceSize * (i + 0.5) - radius, boardY + pieceSize * (j + 0.5) - radius);
                    newMove.setFillColor(sf::Color(255, 0, 0, 96));
                    if (grid[i][j]) 
                        newMove.setPointCount(4);
                    else 
                        newMove.setPointCount(1000);
                    validMoves.push_back(newMove);
                }
            } 
            else 
            {
                oldX = -1;
                oldY = -1;
                validMoves.clear();
            }
        }
    }


}

bool Board::isCheckmate()
{
    return false;
}

bool Board::isStalemate()
{
    return false;
}

void Board::update(sf::RenderWindow& window)
{
    // Brute force check if there is any move?
    moves.clear();
    for (int i1 = 0; i1 < 8; i1++) for (int j1 = 0; j1 < 8; j1++) 
        for (int i2 = 0; i2 < 8; i2++) for (int j2 = 0; j2 < 8; j2++)
            if (lastCheck(i1, j1, i2, j2) && grid[i1][j1]->side == turn) 
                moves.push_back({i1, j1, i2, j2});

    if (moves.size() == 0) std::cerr << (turn ? "gl::WHITE" : "gl::BLACK") << " wins";

    // Game Modes
    switch (gl::curMode)
    {
        case EASY:
            if (turn == 1)
            {
                int r = std::rand() % moves.size();
                makeMove(moves[r][0], moves[r][1], moves[r][2], moves[r][3]);
                turn = 0;
            }
            break;

        case PvP:
            break;
            
        default:
            break;
    }

    if (oldX >= 0)
        oldCell.setPosition(boardX + pieceSize * oldX, boardY + pieceSize * oldY);
    else 
        oldCell.setPosition(-pieceSize, -pieceSize);

    if (newX >= 0)
        newCell.setPosition(boardX + pieceSize * newX, boardY + pieceSize * newY);    
    else 
        newCell.setPosition(-pieceSize, -pieceSize);

    if (isInCheck(turn))
        alertBox.setPosition(boardX + pieceSize * kingPos[turn].x, boardY + pieceSize * kingPos[turn].y);
    else 
        alertBox.setPosition(-pieceSize, -pieceSize);

    screenShot.update(window);
    sf::Color whiteColor = screenShot.copyToImage().getPixel(boardX, boardY);
    sf::Color blackColor = screenShot.copyToImage().getPixel(boardX, boardY + pieceSize);
    for (int i = 0; i < 8; i++)
    {
        if (gl::isFlipped)
        {
            columnIndex[i].setString(char('h' - i));
            rowIndex[i].setString(std::to_string(i + 1));
        }
        else
        {
            columnIndex[i].setString(char('a' + i));
            rowIndex[i].setString(std::to_string(8 - i));
        }

        if (i % 2 == 0)
        {
            columnIndex[i].setColor(whiteColor);
            rowIndex[i].setColor(whiteColor);
        }
        else
        {
            columnIndex[i].setColor(blackColor);
            rowIndex[i].setColor(blackColor);
        }
    }

    board.setTexture(gl::txt.boardTexture[gl::curBoardID]);
}



void Board::drawBoard(sf::RenderWindow &window)
{
    // Draw board
    window.draw(board);

    // Draw box of newest move
    window.draw(newestMoveBox[0]);
    window.draw(newestMoveBox[1]);

    // Draw old cell and new cell
    window.draw(oldCell);
    window.draw(newCell);

    // DRAW ALERT BOX WHEN KING IN CHECK
    window.draw(alertBox);

    // DRAW PIECES
    for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) if (grid[i][j])   
    {
        grid[i][j]->style = "cburnett";

        if (grid[i][j]->shouldMove) 
        {
            int sx = grid[i][j]->movement[0];
            int sy = grid[i][j]->movement[1];
            int ex = grid[i][j]->movement[2];
            int ey = grid[i][j]->movement[3];

            float curPosX = (grid[i][j]->sprite.getPosition().x - boardX) / pieceSize;
            float curPosY = (grid[i][j]->sprite.getPosition().y - boardY) / pieceSize;

            float vecX = ex - sx;
            float vecY = ey - sy;

            if ((sx != ex && abs(curPosX - sx) <= abs(ex - sx)) || 
                (sy != ey && abs(curPosY - sy) <= abs(ey - sy)))
                grid[i][j]->sprite.move(vecX * moveSpeed, vecY * moveSpeed);
            else
                grid[i][j]->shouldMove = 0;
        }
        else
        {
            grid[i][j]->sprite.setPosition(
                boardX + pieceSize * i, 
                boardY + pieceSize * j
            );
        }

        grid[i][j]->draw(window);
    }

    for (auto move: validMoves) window.draw(move);
    window.draw(border);

    for (int i = 0; i < 8; i++)
    {
        window.draw(columnIndex[i]);
        window.draw(rowIndex[i]);
    }
}

bool Board::isInCheck(bool side)
{
    int kingX = kingPos[side].x;
    int kingY = kingPos[side].y;

    for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++) 
        if (grid[i][j] && grid[i][j]->isValidMove(i, j, kingX, kingY, grid)) return true;
    return false;
}

bool Board::checkDetect(int sx, int sy, int ex, int ey)
{
    bool side = grid[sx][sy]->side;
    std::shared_ptr<Piece> tmp = grid[ex][ey] ;
    if (grid[sx][sy]->type == KING) kingPos[side] = sf::Vector2i(ex, ey);

    grid[ex][ey] = grid[sx][sy];
    grid[sx][sy] = nullptr;

    bool flag = isInCheck(side);
    grid[sx][sy] = grid[ex][ey] ;
    grid[ex][ey] = tmp;
    if (grid[sx][sy]->type == KING) kingPos[side] = sf::Vector2i(sx, sy);
    return !flag;
}

void Board::castle(int sx, int sy, int ex, int ey)
{
    int rx = (ex > sx ? 7 : 0),
        ry = sy,
        dx = (ex > sx ? 1 : -1);
    if (grid[rx][ry] && grid[rx][ry]->type == ROOK && grid[rx][ry]->isValidMove(rx, ry, sx + dx, sy, grid))
    {
        moveAnimation(rx, ry, sx + dx, sy);
        moveAnimation(sx, sy, ex, ey);

        grid[sx + dx][sy] = grid[rx][ry];
        grid[ex][ey] = grid[sx][sy];
        grid[rx][ry] = nullptr;
        grid[sx][sy] = nullptr;
    } 
}

void Board::promote(int sx, int sy, int ex, int ey)
{
    moveAnimation(sx, sy, ex, ey);

    grid[ex][ey] = std::make_shared<Queen>(grid[sx][sy]->side);
    grid[sx][sy] = nullptr;
}

void Board::enPassant(int sx, int sy, int ex, int ey)
{
    moveAnimation(sx, sy, ex, ey);

    grid[ex][ey] = grid[sx][sy];
    grid[sx][sy] = nullptr;
    grid[ex][sy] = nullptr;
}

void Board::normalMove(int sx, int sy, int ex, int ey)
{
    moveAnimation(sx, sy, ex, ey);

    grid[ex][ey] = grid[sx][sy];
    grid[sx][sy] = nullptr;
}

void Board::resetEnPassant(int sx, int sy, int ex, int ey)
{
    for (int i = 0; i < 8; i++) for (int j = 0; j < 8; j++)
        if (grid[i][j]) grid[i][j]->enPassant = 0;

    if (grid[ex][ey] && grid[ex][ey]->type == PAWN && abs(ey - sy) == 2) grid[ex][ey]->enPassant = 1;
}

bool Board::isCastle(int sx, int sy, int ex, int ey)
{
    if (grid[sx][sy]->type == KING && sy == ey && abs(sx - ex) == 2)
    {
        int rx = (ex > sx ? 7 : 0),
            ry = sy,
            dx = (ex > sx ? 1 : -1);
        if (grid[rx][ry] && grid[rx][ry]->type == ROOK && grid[rx][ry]->isValidMove(rx, ry, sx + dx, sy, grid))
            return !grid[sx][sy]->hasMoved && !grid[rx][ry]->hasMoved;
    }
    return false;
}

bool Board::isPromote(int sx, int sy, int ex, int ey)
{
    return grid[sx][sy]->type == PAWN
        && grid[sx][sy]->isValidMove(sx, sy, ex, ey, grid)
        && (ey == 0 || ey == 7);
}

bool Board::isEnPassant(int sx, int sy, int ex, int ey)
{
    if (grid[sx][sy]->type != PAWN) return false;
    int d = (grid[sx][sy]->side == gl::BLACK ? 1 : -1);
    if (ey - sy == d && grid[ex][sy] && grid[ex][sy]->type == PAWN && 
        grid[ex][sy]->side != grid[sx][sy]->side && grid[ex][sy]->enPassant) return true;
    return false;
}

bool Board::isNormalMove(int sx, int sy, int ex, int ey)
{
    return grid[sx][sy]->isValidMove(sx, sy, ex, ey, grid);
}

bool Board::lastCheck(int sx, int sy, int ex, int ey) 
{
    if (ex != -1 && grid[sx][sy] && checkDetect(sx, sy, ex, ey))
    {
        if (isCastle(sx, sy, ex, ey)) return true;
        if (isPromote(sx, sy, ex, ey)) return true;
        if (isEnPassant(sx, sy, ex, ey)) return true;
        if (isNormalMove(sx, sy, ex, ey)) return true;
    }   
    return false;   
}

bool Board::makeMove(int sx, int sy, int ex, int ey)
{
    if (lastCheck(sx, sy, ex, ey))
    {
        // Update captured pieces
        if (grid[ex][ey])
        {
            sf::Sprite sprite;
            if (turn == 0)
            sprite.setTexture(gl::txt.capturedIcon[grid[ex][ey]->textureID - grid[ex][ey]->side * 6]);
            capturedPieces[turn].push_back(sprite);
        }

        if (grid[sx][sy]->type == KING) 
            kingPos[grid[sx][sy]->side] = sf::Vector2i(ex, ey);

        makeHistory(sx, sy, ex, ey, grid[ex][ey]);

        // Notation and Exectution
        std::ostringstream oss;
        if (isCastle(sx, sy, ex, ey)) 
        {
            if (ex > sx)
                oss << "O-O";
            else
                oss << "O-O-O";

            castleSound.play();
            castle(sx, sy, ex, ey);
        }
        else if (isEnPassant(sx, sy, ex, ey))
        {
            oss << char('a' + sx) << 'x' << char('a' + ex) << char('0' + 8 - ey) << " e.p.";
            captureSound.play();
            enPassant(sx, sy, ex, ey);
        }
        else if (isNormalMove(sx, sy, ex, ey))
        {
            if (grid[ex][ey]) 
            {
                if (grid[sx][sy]->pieceID != '\0')
                    oss << grid[sx][sy]->pieceID;
                else
                    oss << char('a' + sx);

                oss << 'x' << char('a' + ex) << char('0' + 8 - ey); 
                captureSound.play();
            }
            else 
            {
                if (grid[sx][sy]->pieceID != '\0') 
                    oss << grid[sx][sy]->pieceID;
                    
                oss << char('a' + ex) << char('0' + 8 - ey);
                moveSound.play();
            }

            normalMove(sx, sy, ex, ey);
        }
        else if (isPromote(sx, sy, ex, ey))
        {
            oss << "=Q";
            if (grid[ex][ey]) 
                captureSound.play();
            else 
                moveSound.play();
            promote(sx, sy, ex, ey);
        }

        if (isInCheck(!turn)) oss << '+';
        // if (isCheckmate) oss << '#';

        newestMove = oss.str();

        resetEnPassant(sx, sy, ex, ey);
        newestMoveBox[0].setPosition(boardX + pieceSize * sx, boardY + pieceSize * sy);
        newestMoveBox[1].setPosition(boardX + pieceSize * ex, boardY + pieceSize * ey);
        return true;
    }
    return false;
}

void Board::makeHistory(int sx, int sy, int ex, int ey, std::shared_ptr<Piece> &piece)
{
    // Clear undo history
    while (!unHistory.empty()) unHistory.pop();

    // Create new history
    int moveValue = sx + sy * 10 + ex * 100 + ey * 1000 
                    + grid[sx][sy]->hasMoved * 10000
                    + grid[sx][sy]->enPassant * 100000;
    history.push(std::make_pair(moveValue, piece));
}  

void Board::undo()
{
    if (history.empty()) return;
    std::pair <int, std::shared_ptr<Piece>> curUndo = history.top();
    history.pop();
    unHistory.push(curUndo);

    int sx = (curUndo.first) % 10,
        sy = (curUndo.first / 10) % 10,
        ex = (curUndo.first / 100) % 10,
        ey = (curUndo.first / 1000) % 10,
        castleState = (curUndo.first / 10000) % 10,
        enPassantState = (curUndo.first / 100000) % 10;

    moveAnimation(ex, ey, sx, sy);
    grid[sx][sy] = grid[ex][ey];
    grid[ex][ey] = curUndo.second;

    if (grid[sx][sy] && grid[sx][sy]->type == KING && abs(sx - ex) == 2)
    {
        int rx = (ex > sx ? 7 : 0),
            ry = sy,
            dx = (ex > sx ? 1 : -1);
        
        moveAnimation(sx + dx, sy, rx, ry);
        grid[rx][ry] = grid[sx + dx][sy];
        grid[sx + dx][sy] = nullptr;
        grid[sx][sy]->hasMoved = 0;
        grid[rx][ry]->hasMoved = 0;
    }

    if (grid[sx][sy] && grid[sx][sy]->type == PAWN && abs(ex - sx) == 1 && abs(ey - sy) == 1 && !curUndo.second)
    {
        grid[ex][sy] = std::make_shared<Pawn>(!grid[sx][sy]->side);
        grid[ex][sy]->enPassant = 1;
    }

    if (grid[sx][sy] && grid[sx][sy]->type == KING) grid[sx][sy]->hasMoved = castleState;
    if (grid[sx][sy] && grid[sx][sy]->type == ROOK) grid[sx][sy]->hasMoved = castleState;
    if (grid[sx][sy] && grid[sx][sy]->type == PAWN) grid[sx][sy]->enPassant = enPassantState;

    turn = !turn;
    validMoves.clear();

    newestMoveBox[0].setPosition(boardX + pieceSize * sx, boardY + pieceSize * sy);
    newestMoveBox[1].setPosition(boardX + pieceSize * ex, boardY + pieceSize * ey);
}

void Board::redo()
{
    if (unHistory.empty()) return; 
    std::pair<int , std::shared_ptr<Piece>> curRedo = unHistory.top();
    unHistory.pop();
    history.push(curRedo);

    int sx = (curRedo.first)  % 10,
        sy = (curRedo.first / 10) % 10,
        ex = (curRedo.first / 100) % 10,
        ey = (curRedo.first / 1000) % 10;

    moveAnimation(sx, sy, ex, ey);
    grid[ex][ey] = grid[sx][sy] ; 
    grid[sx][sy] = nullptr;
    
    if (grid[ex][ey] && grid[ex][ey]->type == KING && abs(sx - ex) == 2)
    {
        int rx = (ex > sx ? 7 : 0),   
            ry = sy,
            dx = (ex > sx ? 1 : -1);

        moveAnimation(rx, ry, sx + dx, sy);
        grid[ex][ey]->hasMoved = 1; 
        grid[rx][ry]->hasMoved = 1; 
        grid[sx + dx][sy] = grid[rx][ry];
        grid[rx][ry] = nullptr;
    }

    if (grid[ex][ey] && grid[ex][ey]->type == PAWN && abs(ex - sx) == 1 && abs(ey - sy) == 1 && !curRedo.second) 
        grid[ex][sy] = nullptr;

    turn = !turn;
    validMoves.clear();

    newestMoveBox[0].setPosition(boardX + pieceSize * sx, boardY + pieceSize * sy);
    newestMoveBox[1].setPosition(boardX + pieceSize * ex, boardY + pieceSize * ey);
}

void Board::flip()
{
    for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++)
        std::swap(grid[i][j], grid[7 - i][7 - j]);

    if (newestMoveBox[0].getPosition().x >= 0)
    {
        newestMoveBox[0].setPosition(
            2 * boardX + pieceSize * 7 - newestMoveBox[0].getPosition().x,
            2 * boardY + pieceSize * 7 - newestMoveBox[0].getPosition().y
        );
        newestMoveBox[1].setPosition(
            2 * boardX + pieceSize * 7 - newestMoveBox[1].getPosition().x,
            2 * boardY + pieceSize * 7 - newestMoveBox[1].getPosition().y
        );
    }
}