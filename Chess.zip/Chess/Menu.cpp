#include "Menu.h"

Menu::Menu():
    newGameButton("New game", screenWidth / 2 - 125, screenHeight / 2 - 75, 250, 50),
    loadGameButton("Load Game", screenWidth / 2 - 125, screenHeight / 2 - 15, 250, 50),
    settingsButton("Settings", screenWidth / 2 - 125, screenHeight / 2 + 45, 250, 50),
    exitButton("Exit", screenWidth / 2 - 125, screenHeight / 2 + 105, 250, 50),
    pvpButton("Player vs Player", screenWidth / 2 - 125, screenHeight / 2 - 45, 250, 50),
    pvaiButton("Player vs AI", screenWidth / 2 - 125, screenHeight / 2 + 15, 250, 50)
{
    backgroundImg.loadFromFile("bg_img.png");
    background.setTexture(backgroundImg);
    background.setPosition(0, -500);
    // background.setScale(screenWidth / backgroundImg.getSize().x, screenWidth / backgroundImg.getSize().x);
}

void Menu::handleInput(sf::RenderWindow& window, sf::Event event) 
{
    if (showModeSelect)
    {
        pvpButton.handleInput(window, event);
        pvaiButton.handleInput(window, event);

        if (pvpButton.isClicked(window, event)) 
        {
            showModeSelect = 0;
            stateSwitch = 1;
            gl::prevGameState = gl::curGameState;
            gl::curGameState = GAME; 
            gl::curMode = PvP;
        }

        if (pvaiButton.isClicked(window, event)) 
        {
            showModeSelect = 0;
            stateSwitch = 1;
            gl::prevGameState = gl::curGameState;
            gl::curGameState = GAME; 
            gl::curMode = EASY;
        }   
    }
    else
    {
        newGameButton.handleInput(window, event);
        loadGameButton.handleInput(window, event);
        settingsButton.handleInput(window, event);
        exitButton.handleInput(window, event);

        if (newGameButton.isClicked(window, event))
        {
            // stateSwitch = 1;
            // gl::curGameState = GAME;
            showModeSelect = 1;
        }

        if (loadGameButton.isClicked(window, event))
        {
            // stateSwitch = 1;
            // gl::curGameState = GAME;
        }

        if (settingsButton.isClicked(window, event))
        {
            stateSwitch = 1;
            gl::prevGameState = gl::curGameState;
            gl::curGameState = SETTINGS;
        }

        if (exitButton.isClicked(window, event)) window.close();
    }
}

void Menu::update(sf::RenderWindow& window) {}

void Menu::render(sf::RenderWindow& window) 
{
    if (showModeSelect) {
        pvpButton.draw(window);
        pvaiButton.draw(window);
    }
    else {
        newGameButton.draw(window);
        loadGameButton.draw(window);
        settingsButton.draw(window);
        exitButton.draw(window);
    }
}