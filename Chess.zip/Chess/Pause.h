#pragma once
#include "State.h"

class Pause : public State 
{
private:
    sf::Font                font;
    sf::Text                title;
    sf::Text                titleShadow;
    Button                  resumeButton;
    Button                  restartButton;
    Button                  settingsButton;
    Button                  mainMenuButton;

public:
    Pause();
    void handleInput(sf::RenderWindow& window, sf::Event event) override;
    void update(sf::RenderWindow& window) override;
    void render(sf::RenderWindow& window) override;
};