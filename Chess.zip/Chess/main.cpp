#include "Menu.h"
#include "Game.h"
#include "Pause.h"
#include "Settings.h"

int main() {
    sf::RenderWindow window(sf::VideoMode(screenWidth, screenHeight), "My Chess Game");

    std::shared_ptr<State> menuState        = std::make_shared<Menu>();
    std::shared_ptr<State> gameState        = std::make_shared<Game>();
    std::shared_ptr<State> pauseState       = std::make_shared<Pause>();
    std::shared_ptr<State> settingsState    = std::make_shared<Settings>();

    std::shared_ptr<State> curState = menuState;
    // std::shared_ptr<State> curState = settingsState;
    // std::shared_ptr<State> curState = gameState;

    while (window.isOpen()) {
        // UPDATE CURRENT STATE
        curState->update(window);

        sf::Event event;
        while (window.pollEvent(event)) 
        {
            if (event.type == sf::Event::Closed) window.close();
            curState->handleInput(window, event);
        }

        // DISPLAY CURRENT STATE
        window.clear(sf::Color(236, 235, 233));

        curState->render(window);
        window.display();

        // SWITCH BETWEEN STATES
        if (curState->stateSwitch)
        {
            switch (gl::curGameState)
            {
                case (MENU):
                    curState = menuState;
                    break;
                case (GAME):
                    curState = gameState;
                    break;
                case (PAUSE):
                    curState = pauseState;
                    break;
                case (SETTINGS):
                    curState = settingsState;
                    break;
                default:
                    break;
            }
            curState->stateSwitch = 0;
        }
    }

    return 0;
}