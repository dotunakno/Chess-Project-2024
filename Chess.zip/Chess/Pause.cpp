#include "Pause.h"

Pause::Pause():
    resumeButton("Resume", screenWidth / 2 - 125, screenHeight / 2 - 75, 250, 50),
    restartButton("Restart", screenWidth / 2 - 125, screenHeight / 2 - 15, 250, 50),
    settingsButton("Settings", screenWidth / 2 - 125, screenHeight / 2 + 45, 250, 50),
    mainMenuButton("Main Menu", screenWidth / 2 - 125, screenHeight / 2 + 105, 250, 50)
{
    font.loadFromFile("Fonts/upheavtt.ttf");

    title.setFont(font);
    title.setString("Game Paused");
    title.setCharacterSize(50); // Adjust size as needed
    title.setFillColor(sf::Color::White);
    title.setStyle(sf::Text::Bold);
    title.setPosition((screenWidth - title.getLocalBounds().width) / 2, screenHeight / 2 - 160); // Adjust position as needed

    titleShadow.setFont(font);
    titleShadow.setString("Game Paused");
    titleShadow.setCharacterSize(50); // Adjust size as needed
    titleShadow.setFillColor(sf::Color(200, 200, 200, 100));
    titleShadow.setStyle(sf::Text::Bold);
    titleShadow.setPosition((screenWidth - titleShadow.getLocalBounds().width) / 2 + 3.5, screenHeight / 2 - 160 + 3.5); // Adjust position as needed
}

void Pause::handleInput(sf::RenderWindow& window, sf::Event event) 
{
    resumeButton.handleInput(window, event);
    restartButton.handleInput(window, event);
    settingsButton.handleInput(window, event);
    mainMenuButton.handleInput(window, event);

    // Click Resume button
    if (resumeButton.isClicked(window, event)) 
    {
        stateSwitch = 1;
        gl::prevGameState = gl::curGameState;
        gl::curGameState = GAME;
    }

    // Click Restart button
    if (restartButton.isClicked(window, event))
    {
        stateSwitch = 1;
        gl::prevGameState = gl::curGameState;
        gl::curGameState = GAME;
        gl::resetGame = 1;
    }

    // Click Settings button
    if (settingsButton.isClicked(window, event))
    {
        stateSwitch = 1;
        gl::prevGameState = gl::curGameState;
        gl::curGameState = SETTINGS;
    }

    // Click Menu button
    if (mainMenuButton.isClicked(window, event))
    {
        stateSwitch = 1;
        gl::curGameState = MENU;
        gl::resetGame = 1;
        gl::isFlipped = 0;
        gl::WHITE = 0;
        gl::BLACK = 1;
    }
}

void Pause::update(sf::RenderWindow& window) {};

void Pause::render(sf::RenderWindow& window) 
{
    window.draw(titleShadow);
    window.draw(title);

    resumeButton.draw(window);
    restartButton.draw(window);
    settingsButton.draw(window);
    mainMenuButton.draw(window);
}