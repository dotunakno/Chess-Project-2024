#include "Settings.h"

Settings::Settings():
    audioSlider("Audio Volume", screenWidth / 2 - 100, screenHeight / 2 - 100),
    musicSlider("Background Music Volume", screenWidth / 2 - 100, screenHeight / 2 - 40),
    themeClassic("Classic", screenWidth / 2 - 100, screenHeight / 2 + 50),
    themeModern("Modern", screenWidth / 2 - 100, screenHeight / 2 + 90),
    themeCartoon("Cartoon", screenWidth / 2 - 100, screenHeight / 2 + 130),
    returnButton("Return", 50, 50, 100, 50)
{
    font.loadFromFile("Fonts/upheavtt.ttf");

    audioVolumeText.setFont(font);
    audioVolumeText.setCharacterSize(20);
    audioVolumeText.setFillColor(sf::Color::White);

    musicVolumeText.setFont(font);
    musicVolumeText.setCharacterSize(20);
    musicVolumeText.setFillColor(sf::Color::White);

    for (int i = 0; i < 5; i++)
    {
        boardPreview[i] = new Button("", 
            (screenWidth + pieceSize * (2 * i - 5) + 30 * (2 * i + 1 - 5)) / 2,
            100,
            pieceSize,
            pieceSize * 0.5 ,
        "");
        boardPreview[i]->sprite.setPosition(boardPreview[i]->shape.getPosition());
        boardPreview[i]->sprite.setScale(0.5, 0.5);
        boardPreview[i]->sprite.setTexture(gl::txt.boardTexture[i]);
        boardPreview[i]->sprite.setTextureRect(sf::IntRect(0, 0, 2 * pieceSize, pieceSize));
    }

    for (int i = 0; i < 5; i++)
    {
        piecePreview[i] = new Button("", 
            (screenWidth + pieceSize * (2 * i - 5) + 30 * (2 * i + 1 - 5)) / 2,
            300,
            pieceSize,
            pieceSize * 0.5 ,
        "");
        piecePreview[i]->sprite.setPosition(piecePreview[i]->shape.getPosition());
        // piecePreview[i]->sprite.setScale(0.5, 0.5);
        piecePreview[i]->sprite.setTexture(gl::txt.pieceTexture["chess.com"][2]);
        // piecePreview[i]->sprite.setTextureRect(sf::IntRect(0, 0, 2 * pieceSize, pieceSize));
    }
}

void Settings::handleInput(sf::RenderWindow& window, sf::Event event) 
{
    audioSlider.handleInput(window, event);
    musicSlider.handleInput(window, event);
    themeModern.handleInput(window, event);
    themeClassic.handleInput(window, event);
    themeCartoon.handleInput(window, event);
    returnButton.handleInput(window, event);

    if (returnButton.isClicked(window, event)) {
        stateSwitch = 1;
        gl::curGameState = gl::prevGameState;
    }

    for (int i = 0; i < 5; i++)
        if (boardPreview[i]->isClicked(window, event))
            gl::curBoardID = i;
}

void Settings::update(sf::RenderWindow& window)
{   
    themeModern.update(window);
    themeClassic.update(window);
    themeCartoon.update(window);
}

void Settings::render(sf::RenderWindow& window) 
{
    audioSlider.draw(window);
    musicSlider.draw(window);
    
    themeModern.draw(window);
    themeClassic.draw(window);
    themeCartoon.draw(window);

    window.draw(audioVolumeText);
    window.draw(musicVolumeText);

    returnButton.draw(window);

    for (int i = 0; i < 5; i++) 
        boardPreview[i]->draw(window);

    for (int i = 0; i < 5; i++) 
        piecePreview[i]->draw(window);
}