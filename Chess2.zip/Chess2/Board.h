#pragma once
#include "Pieces.h"
#include "State.h"
#include <stack>

class Board
{
private:
    bool                    clickCount              = 0;
    int                     newX;
    int                     newY;
    int                     oldX;
    int                     oldY;
    sf::Vector2i            kingPos[2];
    sf::Cursor              arrowCursor;
    sf::Cursor              handCursor;
    sf::RectangleShape      oldCell;
    sf::Sprite              newCell;
    sf::RectangleShape      alertBox;
    sf::RectangleShape      newestMoveBox[2];
    sf::RectangleShape      border;
    sf::Font                font;
    sf::Text                columnIndex[8];
    sf::Text                rowIndex[8];
    sf::Texture             screenShot;

    std::vector<sf::CircleShape> validMoves;
    std::vector<std::vector<int> > moves;

public:
    int id = 0;
    bool                    turn                    = 0;
    sf::Sprite              board;
    sf::Texture             frameTexture;

    sf::SoundBuffer         moveBuffer, captureBuffer;
    sf::SoundBuffer         castleBuffer;
    sf::SoundBuffer         checkBuffer;
    sf::SoundBuffer         checkmateBuffer;

    sf::Sound               moveSound; 
    sf::Sound               captureSound;
    sf::Sound               castleSound; 
    sf::Sound               checkSound;
    sf::Sound               checkmateSound;

    std::vector<sf::Sprite> capturedPieces[2];
    std::string             newestMove              = "";

    sf::RectangleShape      promotionBox;
    Button*                 promotionPieces[2][4];

    std::vector<std::vector<std::shared_ptr<Piece> > > grid;
    std::stack<std::pair<int, std::shared_ptr<Piece> > > unHistory, history;

    sf::RenderWindow* win;
    sf::Event   ev;

    Board(sf::RenderWindow& window, sf::Event event);

    void resetGame();
    void handleInput(sf::RenderWindow& window, sf::Event event);
    void update(sf::RenderWindow& window);
    void drawBoard(sf::RenderWindow& window);

    bool isInCheck(bool side);
    bool checkDetect(int sx, int sy, int ex, int ey);

    bool isCheckmate();
    bool isStalemate();

    bool isCastle(int sx, int sy, int ex, int ey);
    bool isPromote(int sx, int sy, int ex, int ey);
    bool isEnPassant(int sx, int sy, int ex, int ey);
    bool isNormalMove(int sx, int sy, int ex, int ey);
    bool lastCheck(int sx, int sy, int ex, int ey);

    void castle(int sx, int sy, int ex, int ey);
    void promote(int sx, int sy, int ex, int ey);
    void enPassant(int sx, int sy, int ex, int ey);
    void normalMove(int sx, int sy, int ex, int ey);
    bool makeMove(int sx, int sy, int ex, int ey);

    void resetEnPassant(int sx, int sy, int e, int ey);

    void makeHistory(int sx, int sy, int ex, int ey, std::shared_ptr<Piece> &piece);
    void undo();
    void redo();

    void moveAnimation(int sx, int sy, int ex, int ey);
    void flip();
};