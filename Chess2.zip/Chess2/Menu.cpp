#include "Menu.h"

Menu::Menu():
    newGameButton("New game", screenWidth / 2 - 125, screenHeight / 2 - 75, 250, 50),
    loadGameButton("Load Game", screenWidth / 2 - 125, screenHeight / 2 - 15, 250, 50),
    settingsButton("Settings", screenWidth / 2 - 125, screenHeight / 2 + 45, 250, 50),
    exitButton("Exit", screenWidth / 2 - 125, screenHeight / 2 + 105, 250, 50),
    pvpButton("Player vs Player", 
        screenWidth * 0.5 - 125, 
        screenHeight * 0.5 - 70, 
        250, 
        50
    ),
    pvaiButton("AAAA", 
        screenWidth * 0.5 - 125, 
        screenHeight * 0.5 + 20, 
        250, 
        50
    ),
    easyButton("",
        screenWidth * 0.5 - pieceSize * 5.5,
        screenHeight * 0.5,
        pieceSize * 3,
        // pieceSize * 3
        0
    ),
    mediumButton("",
        screenWidth * 0.5 - pieceSize * 1.5,
        screenHeight * 0.5,
        pieceSize * 3,
        // pieceSize * 3
        0
    ),
    hardButton("",
        screenWidth * 0.5 + pieceSize * 2.5,
        screenHeight * 0.5,
        pieceSize * 3,
        // pieceSize * 3
        0
    )
{
}

void Menu::handleInput(sf::RenderWindow& window, sf::Event event) 
{
    if (showModeSelect)
    {
        pvpButton.handleInput(window, event);
        pvaiButton.handleInput(window, event);

        if (pvpButton.isClicked(window, event)) 
        {
            showModeSelect = 0;
            stateSwitch = 1;
            gl::prevGameState = gl::curGameState;
            gl::curGameState = GAME; 
            gl::curMode = PvP;
        }

        if (pvaiButton.isClicked(window, event)) 
        {
            showDifficultyAnimation = 1;
            showDifficultySelect = !showDifficultySelect;
            
            // pvp
            // showModeSelect = 0;
            // stateSwitch = 1;
            // gl::prevGameState = gl::curGameState;
            // gl::curGameState = GAME; 
            // gl::curMode = EASY;
        }   
    }
    else
    {
        newGameButton.handleInput(window, event);
        loadGameButton.handleInput(window, event);
        settingsButton.handleInput(window, event);
        exitButton.handleInput(window, event);

        if (newGameButton.isClicked(window, event))
            showModeSelect = 1;

        if (loadGameButton.isClicked(window, event))
        {

        }

        if (settingsButton.isClicked(window, event))
        {
            stateSwitch = 1;
            gl::prevGameState = gl::curGameState;
            gl::curGameState = SETTINGS;
        }

        if (exitButton.isClicked(window, event)) 
            window.close();
    }
}

void Menu::update(sf::RenderWindow& window) 
{
    easyButton.shape.setOutlineThickness(1);
    mediumButton.shape.setOutlineThickness(1);
    hardButton.shape.setOutlineThickness(1);

    // Difficulty select animation
    if (showDifficultySelect)
    {
        if (showDifficultyAnimation)
        {
            if (easyButton.shape.getSize().y < pieceSize * 2.9)
            {   
                pvpButton.shape.move(sf::Vector2f(0, -0.2));
                pvaiButton.shape.move(sf::Vector2f(0, 0.2));

                easyButton.shape.move(sf::Vector2f(0, -0.2));
                mediumButton.shape.setPosition(mediumButton.shape.getPosition() - sf::Vector2f(0, 0.2));
                hardButton.shape.setPosition(hardButton.shape.getPosition() - sf::Vector2f(0, 0.2));

                easyButton.shape.setSize(easyButton.shape.getSize() + sf::Vector2f(0, 0.4));
                mediumButton.shape.setSize(mediumButton.shape.getSize() + sf::Vector2f(0, 0.4));
                hardButton.shape.setSize(hardButton.shape.getSize() + sf::Vector2f(0, 0.4));
            }
            else
                showDifficultyAnimation = 0;
        }
        else
        {
            pvpButton.shape.setPosition(sf::Vector2f(screenWidth * 0.5 - 125, screenHeight * 0.5 - pieceSize * 1.5 - 70));
            pvaiButton.shape.setPosition(sf::Vector2f(screenWidth * 0.5 - 125, screenHeight * 0.5 + pieceSize * 1.5 + 20));

            easyButton.shape.setPosition(screenWidth * 0.5 - pieceSize * 5.5, screenHeight * 0.5 - pieceSize * 1.5);
            mediumButton.shape.setPosition(screenWidth * 0.5 - pieceSize * 1.5, screenHeight * 0.5 - pieceSize * 1.5);
            hardButton.shape.setPosition(screenWidth * 0.5 + pieceSize * 2.5, screenHeight * 0.5 - pieceSize * 1.5);

            easyButton.shape.setSize(sf::Vector2f(pieceSize * 3, pieceSize * 3));
            mediumButton.shape.setSize(sf::Vector2f(pieceSize * 3, pieceSize * 3));
            hardButton.shape.setSize(sf::Vector2f(pieceSize * 3, pieceSize * 3));
        }
    }
    else
    {
        if (showDifficultyAnimation)
        {
            if (easyButton.shape.getSize().y > pieceSize * 0.1)
            {
                pvpButton.shape.move(sf::Vector2f(0, 0.2));
                pvaiButton.shape.move(sf::Vector2f(0, -0.2));

                easyButton.shape.setPosition(easyButton.shape.getPosition() + sf::Vector2f(0, 0.2));
                mediumButton.shape.setPosition(mediumButton.shape.getPosition() + sf::Vector2f(0, 0.2));
                hardButton.shape.setPosition(hardButton.shape.getPosition() + sf::Vector2f(0, 0.2));

                easyButton.shape.setSize(easyButton.shape.getSize() - sf::Vector2f(0, 0.4));
                mediumButton.shape.setSize(easyButton.shape.getSize() - sf::Vector2f(0, 0.4));
                hardButton.shape.setSize(easyButton.shape.getSize() - sf::Vector2f(0, 0.4));
            }
            else
                showDifficultyAnimation = 0;
        }
        else
        {
            pvpButton.shape.setPosition(sf::Vector2f(screenWidth * 0.5 - 125, screenHeight * 0.5 - 70));
            pvaiButton.shape.setPosition(sf::Vector2f(screenWidth * 0.5 - 125, screenHeight * 0.5 + 20));

            easyButton.shape.setPosition(screenWidth * 0.5 - pieceSize * 5.5, screenHeight * 0.5);
            mediumButton.shape.setPosition(screenWidth * 0.5 - pieceSize * 1.5, screenHeight * 0.5);
            hardButton.shape.setPosition(screenWidth * 0.5 + pieceSize * 2.5, screenHeight * 0.5);

            easyButton.shape.setSize(sf::Vector2f(pieceSize * 3, 0));
            mediumButton.shape.setSize(sf::Vector2f(pieceSize * 3, 0));
            hardButton.shape.setSize(sf::Vector2f(pieceSize * 3, 0));

            easyButton.shape.setOutlineThickness(0);
            mediumButton.shape.setOutlineThickness(0);
            hardButton.shape.setOutlineThickness(0);
        }
    }

    pvpButton.text.setPosition(
        pvpButton.shape.getPosition().x + pvpButton.shape.getSize().x / 2 - floor(pvpButton.text.getLocalBounds().width / 2),
        pvpButton.shape.getPosition().y + pvpButton.shape.getSize().y / 2 - floor(pvpButton.text.getLocalBounds().height / 2)
    );
    pvaiButton.text.setPosition(
        pvaiButton.shape.getPosition().x + pvaiButton.shape.getSize().x / 2  - floor(pvaiButton.text.getLocalBounds().width / 2),
        pvaiButton.shape.getPosition().y + pvaiButton.shape.getSize().y / 2 - floor(pvaiButton.text.getLocalBounds().height / 2)
    );
}

void Menu::render(sf::RenderWindow& window) 
{
    if (showModeSelect) {
        pvpButton.draw(window);
        pvaiButton.draw(window);
        easyButton.draw(window);
        mediumButton.draw(window);
        hardButton.draw(window);
    }
    else {
        newGameButton.draw(window);
        loadGameButton.draw(window);
        settingsButton.draw(window);
        exitButton.draw(window);
    }
}