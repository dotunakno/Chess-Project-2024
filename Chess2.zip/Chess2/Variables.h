#pragma once
#include "Textures.h"

const float                 screenWidth             = 1102;
const float                 screenHeight            = 640;
const float                 boardSize               = screenHeight * 0.85;
const float                 boardX                  = 50;
const float                 boardY                  = 50;
const float                 pieceSize               = boardSize * 0.125;
const float                 buttonWidth             = screenWidth * 0.75;
const float                 buttonHeight            = screenHeight * 0.25;
const float                 radius                  = pieceSize * 0.15;
const float                 FPS                     = 60;
const float                 moveSpeed               = 3;
const float                 iconSize                = 16;

enum GameMode               {PvP, EASY, MEDIUM, HARD};
enum GameState              {MENU, GAME, PAUSE, SETTINGS, PAUSED};
enum Style                  {CLASSIC, MODERN, CARTOON};

namespace gl
{
    inline GameMode         curMode;
    inline GameState        curGameState;
    inline GameState        prevGameState;
    inline Style            curStyle                = CLASSIC;
    inline bool             resetGame;
    inline int              audioVolume;
    inline int              musicVolume;
    inline bool             isFlipped               = 0;
    inline bool             WHITE                   = 0;
    inline bool             BLACK                   = 1;
    inline TXT              txt;
    inline int              curBoardID              = 0;
    inline int              curPieceID              = 0;
    inline float            deltaTime;
    inline bool             gameFinished            = 0;
}   