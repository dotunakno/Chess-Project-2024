#pragma once
#include "State.h"

class Settings : public State 
{
private:
    Slider                  audioSlider;
    Slider                  musicSlider;
    sf::Font                f1, f2;
    sf::Text                audioVolumeText;
    sf::Text                musicVolumeText;
    Button                  returnButton;
    Button*                 boardThumbnail[5];
    Button*                 pieceThumbnail[5];
    sf::Text                boardText;
    sf::Text                pieceText;
public:
    Settings();
    void handleInput(sf::RenderWindow& window, sf::Event event) override;
    void update(sf::RenderWindow& window) override;
    void render(sf::RenderWindow& window) override;
};