#pragma once
#include <iostream>
#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window/Cursor.hpp>
#include "Variables.h"
#include "Textures.h"

enum Type {PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING};

#define Side    bool
// #define gl::WHITE   1
// #define gl::BLACK   0

class Piece
{
public:
    bool                    side;
    bool                    shouldMove              = 0;
    bool                    isSelected              = 0;
    bool                    hasMoved                = 0;
    bool                    enPassant               = 0;
    std::vector<int>        movement                = {-1, -1, -1, -1};
    std::string             style                   = "chess.com";
    Type                    type;
    char                    pieceID;
    int                     textureID;
    sf::Sprite              sprite;
    sf::RectangleShape      selectBox;

    Piece(bool side);
    ~Piece();
    virtual bool isValidMove(int sx, int sy, int ex, int ey, std::vector<std::vector<std::shared_ptr<Piece> > > &grid) = 0;
    void draw(sf::RenderWindow& window);
};

class Pawn: public Piece 
{
public:
    Pawn(bool side);
    ~Pawn();
    bool isValidMove(int sx, int sy, int ex, int ey, std::vector<std::vector<std::shared_ptr<Piece> > > &grid) override;
};

class Knight: public Piece 
{
private:
    std::vector<std::pair<int, int> > dir = {{1, 2}, {1, -2}, {2, 1}, {2, -1}, {-1, 2}, {-1, -2}, {-2, 1}, {-2, -1}};

public:
    Knight(bool side);
    ~Knight();
    bool isValidMove(int sx, int sy, int ex, int ey, std::vector<std::vector<std::shared_ptr<Piece> > > &grid) override;
};

class Bishop: public Piece 
{
public:
    Bishop(bool side);
    ~Bishop();
    bool isValidMove(int sx, int sy, int ex, int ey, std::vector<std::vector<std::shared_ptr<Piece> > > &grid) override;
};

class Rook: public Piece 
{
public:
    Rook(bool side);
    ~Rook();
    bool isValidMove(int sx, int sy, int ex, int ey, std::vector<std::vector<std::shared_ptr<Piece> > > &grid) override;
};

class Queen: public Piece 
{
public:
    Queen(bool side);
    ~Queen();
    bool isValidMove(int sx, int sy, int ex, int ey, std::vector<std::vector<std::shared_ptr<Piece> > > &grid) override;
};

class King: public Piece 
{
private:
    std::vector<std::pair<int, int> > dir = {{1, 0}, {1, 1}, {1, -1}, {-1, 0}, {-1, 1}, {-1, -1}, {0, 1}, {0, -1}};

public:
    King(bool side);
    ~King();
    bool isValidMove(int sx, int sy, int ex, int ey, std::vector<std::vector<std::shared_ptr<Piece> > > &grid) override;
};