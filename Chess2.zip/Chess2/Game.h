#pragma once
#include "State.h"
#include "Board.h"

class Game : public State 
{
private:
    Board                   mainBoard;
    Button                  beginningButton;
    Button                  previousButton;
    Button                  flipButton;
    Button                  nextButton;
    Button                  endingButton;
    Button                  undoButton;
    Button                  redoButton;
    Button                  resetButton;
    Button                  pauseButton;
    Button                  upButton;
    Button                  downButton;
    ConfirmBox              resetConfirm;
    sf::Font                font;
    sf::Font                historyFont;
    sf::Sprite              whitePlayer;
    sf::Sprite              blackPlayer;
    sf::RectangleShape      textBox;
    int                     maxDisplay              = 5;
    sf::Text                moveCount[5];
    sf::Text                whiteMove[5];
    sf::Text                blackMove[5];
    int                     startPos                = 0;
    Button                  p1Name;
    Button                  p2Name;
    sf::RectangleShape      resultBox;
    sf::Text                result;
    sf::Text                reason;
    Button                  rematchButton;
    Button                  mainMenuButton;
    Button                  reviewButton;

    std::vector<std::string> whiteHistory, blackHistory;

public:
    Game(sf::RenderWindow& window, sf::Event event);
    void handleInput(sf::RenderWindow& window, sf::Event event) override;
    void update(sf::RenderWindow& window) override;
    void render(sf::RenderWindow& window) override;
};