#pragma once
#include <iostream>
#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/Window/Cursor.hpp>
#include <filesystem>

class TXT
{
public:
    std::array<std::string, 5> styles = {"chess.com", "chess.com", "cartoon", "cburnett", "cburnett"};
    std::map<std::string, std::array<sf::Texture, 12>> pieceTexture;
    std::array<sf::Texture, 5> boardTexture;
    sf::Texture wAvt, bAvt;
    sf::Texture capturedIcon[6];
    
    TXT()
    {
        for (std::string style: styles) for (int i = 0; i < 12; i++)
            pieceTexture[style][i].loadFromFile("Assets/" + style + "/" + std::to_string(i) + ".png");

        for (int i = 0; i < 6; i++)
            capturedIcon[i].loadFromFile("Assets/icons/" + std::to_string(i) + ".png");
        
        boardTexture[0].loadFromFile("Assets/boards/blue.png");
        boardTexture[1].loadFromFile("Assets/boards/green.png");
        boardTexture[2].loadFromFile("Assets/boards/newspaper.png");
        boardTexture[3].loadFromFile("Assets/boards/purple.png");
        boardTexture[4].loadFromFile("Assets/boards/blue.png");
    }
};

/*
0   =   white pawn
1   =   white knight
2   =   white bishop
3   =   white rook
4   =   white queen
5   =   white king
6   =   black pawn
7   =   black knight
8   =   black bishop
9   =   black rook
10  =   black queen
11  =   black king
*/