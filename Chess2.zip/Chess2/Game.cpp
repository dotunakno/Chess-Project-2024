#include "Game.h"

Game::Game(sf::RenderWindow& window, sf::Event event):
    mainBoard(window, event),
    beginningButton("",
        boardX + boardSize + 50 + pieceSize - pieceSize * 0.5 - 20, 
        boardY + pieceSize * 2.2,
        pieceSize, 
        pieceSize * 0.7,
        "beginning"
    ),
    previousButton("",
        boardX + boardSize + 50 + pieceSize * 2 - pieceSize * 0.5 - 10, 
        boardY + pieceSize * 2.2,
        pieceSize, 
        pieceSize * 0.7,
        "left"
    ),
    flipButton("",
        boardX + boardSize + 50 + pieceSize * 3 - pieceSize * 0.5, 
        boardY + pieceSize * 2.2,
        pieceSize, 
        pieceSize * 0.7,
        "flip"
    ),
    nextButton("",
        boardX + boardSize + 50 + pieceSize * 4 - pieceSize * 0.5 + 10, 
        boardY + pieceSize * 2.2,
        pieceSize, 
        pieceSize * 0.7,
        "right"
    ),
    endingButton("",
        boardX + boardSize + 50 + pieceSize * 5 - pieceSize * 0.5 + 20, 
        boardY + pieceSize * 2.2,
        pieceSize, 
        pieceSize * 0.7,
        "ending"
    ),
    undoButton("",
        boardX + boardSize + 50 + pieceSize * 2 - pieceSize * 0.5 - 10, 
        boardY + pieceSize * 5.1,   
        pieceSize, 
        pieceSize * 0.7,
        "undo"
    ),
    pauseButton("", 
        boardX + boardSize + 50 + pieceSize * 3 - pieceSize * 0.5, 
        boardY + pieceSize * 5.1,
        pieceSize, 
        pieceSize * 0.7,
        "pause"
    ),
    redoButton("", 
        boardX + boardSize + 50 + pieceSize * 4 - pieceSize * 0.5 + 10, 
        boardY + pieceSize * 5.1,
        pieceSize, 
        pieceSize * 0.7,
        "redo"
    ),
    resetButton("Reset", 
        pieceSize * 8, 
        pieceSize * 6, 
        screenWidth - boardSize, 
        pieceSize,
        "reset"
    ),
    resetConfirm("Do you want to reset the game?", 
        400, 
        200, 
        boardSize / 2 - 200, 
        boardSize / 2 - 100
    ),
    upButton("",
        boardX + boardSize + 50 + pieceSize * 5,
        boardY + pieceSize * 3,
        pieceSize,
        pieceSize,
        "up"
    ),
    downButton("",
        boardX + boardSize + 50 + pieceSize * 5,
        boardY + pieceSize * 4,
        pieceSize,
        pieceSize,
        "down"
    ),
    p1Name("Player 1",
        boardX + boardSize + 50,
        boardY + pieceSize,
        pieceSize * 6,
        pieceSize
    ),
    p2Name("Player 2",
        boardX + boardSize + 50,
        boardY + pieceSize * 6,
        pieceSize * 6,
        pieceSize
    ),
    rematchButton("Rematch",
        boardX + pieceSize * 2 + 10,
        boardY + pieceSize * 3.5 + 10,
        pieceSize * 4 - 10 * 2,
        pieceSize * 1 - 10 * 2
    ),
    mainMenuButton("Menu",
        boardX + pieceSize * 2 + 10,
        boardY + pieceSize * 4.5 + 10,
        pieceSize * 2 - 10 * 2,
        pieceSize * 1 - 10 * 2
    ),
    reviewButton("Review",
        boardX + pieceSize * 4 + 10,
        boardY + pieceSize * 4.5 + 10,
        pieceSize * 2 - 10 * 2,
        pieceSize * 1 - 10 * 2
    )
{
    font.loadFromFile("Fonts/arial.ttf");
    historyFont.loadFromFile("Fonts/NotoSans.ttf");
    
    mainBoard.resetGame();

    whitePlayer.setTexture(gl::txt.wAvt);
    blackPlayer.setTexture(gl::txt.bAvt);

    whitePlayer.setScale(
        pieceSize / whitePlayer.getLocalBounds().width, 
        pieceSize / whitePlayer.getLocalBounds().height
    );

    blackPlayer.setScale(
        pieceSize / blackPlayer.getLocalBounds().width, 
        pieceSize / blackPlayer.getLocalBounds().height
    );

    whitePlayer.setPosition(pieceSize * 8, pieceSize * 7);
    blackPlayer.setPosition(pieceSize * 8, 0);

    textBox.setFillColor(sf::Color(250, 250, 250));
    textBox.setPosition(boardX + boardSize + 50, boardY + pieceSize);
    textBox.setSize(sf::Vector2f(pieceSize * 6, pieceSize * 6));
    textBox.setOutlineColor(sf::Color::Black); 
    textBox.setOutlineThickness(1.f);

    beginningButton.shape.setOutlineColor(sf::Color::Black);
    beginningButton.shape.setOutlineThickness(1.f);

    previousButton.shape.setOutlineColor(sf::Color::Black);
    previousButton.shape.setOutlineThickness(1.f);

    flipButton.shape.setOutlineColor(sf::Color::Black);
    flipButton.shape.setOutlineThickness(1.f);

    nextButton.shape.setOutlineColor(sf::Color::Black);
    nextButton.shape.setOutlineThickness(1.f);

    endingButton.shape.setOutlineColor(sf::Color::Black);
    endingButton.shape.setOutlineThickness(1.f);

    for (int i = 0; i < 5; i++) {
        moveCount[i].setFont(historyFont);
        whiteMove[i].setFont(historyFont);
        blackMove[i].setFont(historyFont);

        moveCount[i].setCharacterSize(20);
        whiteMove[i].setCharacterSize(20);
        blackMove[i].setCharacterSize(20);

        moveCount[i].setFillColor(sf::Color::Black);
        whiteMove[i].setFillColor(sf::Color::Black);
        blackMove[i].setFillColor(sf::Color::Black);
    }

    resultBox.setPosition(
        boardX + pieceSize * 2 - 20, 
        boardY + pieceSize * 2.5 - 20
    );
    resultBox.setSize(sf::Vector2f(pieceSize * 4 + 20 * 2, pieceSize * 3 + 20 * 2));
    resultBox.setOutlineColor(sf::Color::Black);
    resultBox.setOutlineThickness(1);

    result.setString("Black won");
    result.setFont(font);
    result.setFillColor(sf::Color::Black);
    result.setPosition(
        boardX + pieceSize * 4 - result.getLocalBounds().width / 2,
        boardY + pieceSize * 2.5
    );

    reason.setString("by checkmate");
    reason.setFont(font);
    reason.setFillColor(sf::Color::Black);
    reason.setCharacterSize(16);
    reason.setPosition(
        boardX + pieceSize * 4 - reason.getLocalBounds().width / 2,
        boardY + pieceSize * 3 + 5
    );
}

void Game::handleInput(sf::RenderWindow& window, sf::Event event) 
{
    mainBoard.handleInput(window, event);

    if (resetConfirm.popupOpen) 
    {
        int t = resetConfirm.handleInput(window, event);
        if (t != 0) 
            resetConfirm.popupOpen = 0;
        if (t == 1) 
            gl::resetGame = 1;
    }
    else 
    {
        undoButton.handleInput(window, event);
        redoButton.handleInput(window, event);
        resetButton.handleInput(window, event);
        pauseButton.handleInput(window, event);

        if (flipButton.isClicked(window, event))
        {
            std::swap(gl::WHITE, gl::BLACK);
            mainBoard.flip();
            gl::isFlipped = !gl::isFlipped;
        }

        if (undoButton.isClicked(window, event)) 
        {
            int times = (gl::curMode == PvP ? 1 : 2);
            while (times--)
            {
                mainBoard.undo();
                if (mainBoard.turn == 0 && whiteHistory.size())
                    whiteHistory.pop_back();
                if (mainBoard.turn == 1 && blackHistory.size())
                    blackHistory.pop_back();
            }
        }

        if (redoButton.isClicked(window, event)) 
        {
            mainBoard.redo();
            std::cerr << mainBoard.newestMove << " ";
        }
        if (pauseButton.isClicked(window, event))
        {
            stateSwitch = 1;
            gl::prevGameState = gl::curGameState;
            gl::curGameState = PAUSE;
        }
        // if (resetButton.isClicked(window, event)) resetConfirm.popupOpen = 1;

        if (upButton.isClicked(window, event) && startPos > 0) 
            startPos--;
        if (downButton.isClicked(window, event) && startPos + 5 < whiteHistory.size()) 
            startPos++;
    }

    if (gl::gameFinished)
    {
        if (rematchButton.isClicked(window, event))
        {
            gl::resetGame = 1;
            gl::gameFinished = 0;
        }
        if (mainMenuButton.isClicked(window, event))
        {
            gl::resetGame = 1;
            stateSwitch = 1;
            gl::prevGameState = gl::curGameState;
            gl::curGameState = MENU;
            gl::gameFinished = 0;
        }
        if (reviewButton.isClicked(window, event))
            gl::gameFinished = 0;
    }
}

void Game::update(sf::RenderWindow& window)
{
    if (gl::resetGame)
    {
        whiteHistory.clear();
        blackHistory.clear();
        mainBoard.resetGame();
        gl::resetGame = 0;
    }

    if (mainBoard.newestMove != "")
    {   
        if (mainBoard.turn == 1)
        {
            whiteHistory.push_back(mainBoard.newestMove);
            if (startPos + 5 + 1 == whiteHistory.size()) startPos++;
        }
        else
            blackHistory.push_back(mainBoard.newestMove);
            
        mainBoard.newestMove = "";
    }

    for (int i = 0; i < 5; i++)
    {
        if (startPos + i < whiteHistory.size())
        {
            moveCount[i].setString(std::to_string(startPos + i + 1));
            whiteMove[i].setString(whiteHistory[startPos + i]);
        }
        else
        {
            moveCount[i].setString("");
            whiteMove[i].setString("");
        }

        if (startPos + i < blackHistory.size())
            blackMove[i].setString(blackHistory[startPos + i]);
        else
            blackMove[i].setString("");
    }

    mainBoard.update(window);  
}

void Game::render(sf::RenderWindow& window) 
{
    // Draw mainboard
    mainBoard.drawBoard(window);

    // Draw history board
    window.draw(textBox);

    // // Disable redo button if necessary
    // if (mainBoard.unHistory.empty())
    //     redoButton.idleColor = sf::Color::Red;
    // else 
    //     redoButton.idleColor = sf::Color(100, 100, 100, 200);

    // resetButton.draw(window);

    // // Draw popup to confirm reset
    // if (resetConfirm.popupOpen) resetConfirm.draw(window);

    // Draw captured pieces
    for (int i = 0; i < mainBoard.capturedPieces[0].size(); i++)
    {
        mainBoard.capturedPieces[0][i].setPosition(
            pieceSize * 9 + iconSize * i, 
            pieceSize * 7.5 - iconSize * 0.5
        );
        window.draw(mainBoard.capturedPieces[0][i]);
    }

    for (int i = 0; i < mainBoard.capturedPieces[1].size(); i++)
    {
        mainBoard.capturedPieces[1][i].setPosition(
            pieceSize * 9 + iconSize * i, 
            pieceSize * 0.5 - iconSize * 0.5
        );
        window.draw(mainBoard.capturedPieces[1][i]);
    }

    // Draw move history
    for (int i = 0; i < 5; i++)
    {
        moveCount[i].setPosition(
            textBox.getPosition().x + pieceSize * 0.5 - moveCount[i].getLocalBounds().width * 0.5,
            textBox.getPosition().y + pieceSize * (2 + 0.4 * i)
        );
        whiteMove[i].setPosition(
            textBox.getPosition().x + pieceSize + 10, 
            textBox.getPosition().y + pieceSize * (2 + 0.4 * i)
        );
        blackMove[i].setPosition(
            textBox.getPosition().x + pieceSize * 3 + 10, 
            textBox.getPosition().y + pieceSize * (2 + 0.4 * i)
        );

        window.draw(moveCount[i]);
        window.draw(whiteMove[i]);
        window.draw(blackMove[i]);
    }

    // Draw main buttons
    beginningButton.draw(window);
    previousButton.draw(window);
    flipButton.draw(window);
    nextButton.draw(window);
    endingButton.draw(window);

    undoButton.draw(window);
    pauseButton.draw(window);
    redoButton.draw(window);

    upButton.draw(window);
    downButton.draw(window);

    // Draw 2 players' names
    p1Name.draw(window);
    p2Name.draw(window);

    // Result
    if (gl::gameFinished)
    {
        window.draw(resultBox);
        window.draw(result);
        window.draw(reason);
        rematchButton.draw(window);
        mainMenuButton.draw(window);
        reviewButton.draw(window);
    }
}