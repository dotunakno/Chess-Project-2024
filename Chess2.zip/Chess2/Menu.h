#pragma once
#include "State.h"

class Menu : public State 
{
private:
    bool                    showModeSelect          = 0;
    bool                    showDifficultySelect    = 0;
    bool                    showDifficultyAnimation = 0;
    sf::Texture             texture;
    sf::Sprite              sprite;
    sf::Texture             backgroundImg;
    sf::Sprite              background;
    Button                  newGameButton;
    Button                  loadGameButton;
    Button                  settingsButton;
    Button                  exitButton;
    Button                  pvpButton;
    Button                  pvaiButton;
    Button                  easyButton;
    Button                  mediumButton;
    Button                  hardButton;

public:
    Menu();
    void handleInput(sf::RenderWindow& window, sf::Event event) override;
    void update(sf::RenderWindow& window) override;
    void render(sf::RenderWindow& window) override;
};