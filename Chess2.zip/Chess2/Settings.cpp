#include "Settings.h"

Settings::Settings():
    audioSlider("Audio Volume",
        (screenWidth - (pieceSize + 30) * 5 + 30) / 2 - 10, 
        100
    ),
    musicSlider("Background Music Volume", 
        (screenWidth - (pieceSize + 30) * 5 + 30) / 2 - 10, 
        200
    ),
    returnButton("Return", 50, 50, 100, 50)
{
    f1.loadFromFile("Fonts/upheavtt.ttf");
    f2.loadFromFile("Fonts/segoe.ttf");

    audioSlider.text.setFont(f2);
    audioSlider.text.setFillColor(sf::Color::Black);
    
    musicSlider.text.setFont(f2);
    musicSlider.text.setFillColor(sf::Color::Black);

    audioVolumeText.setFont(f1);
    audioVolumeText.setCharacterSize(20);
    audioVolumeText.setFillColor(sf::Color::White);

    musicVolumeText.setFont(f1);
    musicVolumeText.setCharacterSize(20);
    musicVolumeText.setFillColor(sf::Color::White);

    for (int i = 0; i < 5; i++)
    {
        boardThumbnail[i] = new Button("", 
            (screenWidth + pieceSize * (2 * i - 5) + 30 * (2 * i + 1 - 5)) / 2,
            300,
            pieceSize,
            pieceSize * 0.5,
        "");
        boardThumbnail[i]->sprite.setPosition(boardThumbnail[i]->shape.getPosition());
        boardThumbnail[i]->sprite.setScale(0.5, 0.5);
        boardThumbnail[i]->sprite.setTexture(gl::txt.boardTexture[i]);
        boardThumbnail[i]->sprite.setTextureRect(sf::IntRect(0, 0, 2 * pieceSize, pieceSize));
    }

    for (int i = 0; i < 5; i++)
    {
        pieceThumbnail[i] = new Button("", 
            (screenWidth + pieceSize * (2 * i - 5) + 30 * (2 * i + 1 - 5)) / 2,
            400,
            pieceSize,
            pieceSize,
        "");
        pieceThumbnail[i]->sprite.setPosition(pieceThumbnail[i]->shape.getPosition());
        pieceThumbnail[i]->sprite.setTexture(gl::txt.pieceTexture[gl::txt.styles[i]][1]);
    }

    boardText.setFont(f2);
    boardText.setCharacterSize(20);
    boardText.setFillColor(sf::Color::Black);
    boardText.setString("Board");
    boardText.setPosition(boardThumbnail[0]->shape.getPosition() - sf::Vector2f(10, 40));

    pieceText.setFont(f2);
    pieceText.setCharacterSize(20);
    pieceText.setFillColor(sf::Color::Black);
    pieceText.setString("Piece set");
    pieceText.setPosition(pieceThumbnail[0]->shape.getPosition() - sf::Vector2f(10, 40));
}

void Settings::handleInput(sf::RenderWindow& window, sf::Event event) 
{
    audioSlider.handleInput(window, event);
    musicSlider.handleInput(window, event);
    returnButton.handleInput(window, event);

    if (returnButton.isClicked(window, event)) {
        stateSwitch = 1;
        gl::curGameState = gl::prevGameState;
    }

    for (int i = 0; i < 5; i++)
        if (boardThumbnail[i]->isClicked(window, event))
            gl::curBoardID = i;

    for (int i = 0; i < 5; i++)
        if (pieceThumbnail[i]->isClicked(window, event))
            gl::curPieceID = i;
}

void Settings::update(sf::RenderWindow& window)
{
    for (int i = 0; i < 5; i++)
    {
        if (i == gl::curBoardID) 
            boardThumbnail[i]->shape.setOutlineThickness(3);
        else 
            boardThumbnail[i]->shape.setOutlineThickness(1);
    }

    for (int i = 0; i < 5; i++)
    {
        if (i == gl::curPieceID) 
            pieceThumbnail[i]->shape.setOutlineThickness(3);
        else 
            pieceThumbnail[i]->shape.setOutlineThickness(1);
    }
}

void Settings::render(sf::RenderWindow& window) 
{
    audioSlider.draw(window);
    musicSlider.draw(window);
    
    window.draw(audioVolumeText);
    window.draw(musicVolumeText);

    returnButton.draw(window);

    for (int i = 0; i < 5; i++) 
        boardThumbnail[i]->draw(window);

    for (int i = 0; i < 5; i++) 
        pieceThumbnail[i]->draw(window);

    window.draw(boardText);
    window.draw(pieceText);
}