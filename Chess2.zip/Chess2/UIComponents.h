#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>
#include "Variables.h"
#include <memory>

enum buttonState    {IDLE, HOVERED, PRESSED, DISABLED};
enum Align          {LEFT, CENTER};

class Button
{
public:
    bool                    hasShadow               = 0;
    float                   x, y, width, height;
    sf::Font                font;
    sf::Text                text;
    sf::Cursor              arrowCursor;
    sf::Cursor              handCursor;
    sf::RectangleShape      shape;
    sf::RectangleShape      shadow;
    sf::Color               color;
    sf::Color               idleColor;
    sf::Color               hoveredColor            = sf::Color(150, 150, 150, 255);
    sf::Color               pressedColor            = sf::Color(0, 255, 0, 96);
    buttonState             state;
    sf::Texture             texture;
    sf::Sprite              sprite;  
    Align                   textAlignment;

    Button(
        std::string content, 
        float x, float y, 
        float width = screenWidth, float height = pieceSize, 
        std::string imgName = ""
        )
    {
        arrowCursor.loadFromSystem(sf::Cursor::Arrow);
        handCursor.loadFromSystem(sf::Cursor::Hand);

        font.loadFromFile("Fonts/upheavtt.ttf");
        state = IDLE;  
        idleColor = sf::Color::Transparent;
        textAlignment = LEFT;

        this->x = x;
        this->y = y;
        this->width = width;
        this->height = height;

        shape.setPosition(x, y);
        shape.setSize(sf::Vector2f(width, height));
        shape.setOutlineColor(sf::Color::Black);
        shape.setOutlineThickness(1);

        shadow.setFillColor(sf::Color(50, 50, 50, 150));
        shadow.setPosition(x + 5, y + 5);
        shadow.setSize(sf::Vector2f(width, height));

        if (imgName != "")
        { 
            texture.loadFromFile("Assets/buttons/" + imgName + ".png");
            sprite.setTexture(texture);
            sprite.setPosition(
                x + width * 0.5 - sprite.getLocalBounds().width * 0.5,
                y + height * 0.5 - sprite.getLocalBounds().height * 0.5
            );
        }

        text.setFont(font);
        text.setString(content);
        text.setCharacterSize(24);
        text.setFillColor(sf::Color::Black);
        text.setPosition(
            x + height * 0.5 - text.getLocalBounds().height * 0.5 - text.getLocalBounds().top, 
            y + height * 0.5 - text.getLocalBounds().height * 0.5 - text.getLocalBounds().top
        );
    }

    bool isMouseOver(sf::RenderWindow& window)
    {
        return shape.getGlobalBounds().contains(
            sf::Mouse::getPosition(window).x, 
            sf::Mouse::getPosition(window).y
        );
    }

    void enableShadow()
    {
        hasShadow = 1;
    }

    bool isClicked(sf::RenderWindow& window, sf::Event event)
    {
        return event.type == sf::Event::MouseButtonPressed && isMouseOver(window);
    }

    void handleInput(sf::RenderWindow& window, sf::Event event)
    {
        if (isMouseOver(window)) 
        {
            state = HOVERED;
            // window.setMouseCursor(handCursor);
        }
        else state = IDLE;
    }

    void draw(sf::RenderWindow& window)
    {   
        switch (state)
        {
            case IDLE:
                color = idleColor;
                break;
            case HOVERED:
                color = hoveredColor;
                break;
            case PRESSED:
                color = pressedColor;
                break;
            default:
                color = sf::Color::Black;
                break;
        }

        shape.setFillColor(color);
        // sprite.setPosition(
        //     x + width * 0.5 - sprite.getLocalBounds().width * 0.5,
        //     y + height * 0.5 - sprite.getLocalBounds().height * 0.5
        // );

        if (hasShadow) window.draw(shadow);
        window.draw(shape);
        window.draw(text);
        window.draw(sprite);
    }    
};

class Slider {
public:
    sf::Font                font;
    sf::Text                text;
    sf::RectangleShape      sliderBar;
    sf::RectangleShape      sliderHandle;
    float                   barLength;
    float                   barWidth;
    float                   handleLength;
    float                   handleWidth;
    float                   minPosition;
    float                   maxPosition;
    float                   curVal;
    bool                    dragging                = 0;

    Slider(const std::string &label, float posX, float posY) 
    {
        font.loadFromFile("Fonts/upheavtt.ttf");

        barLength       = pieceSize * 5 + 30 * 4;
        barWidth        = 7;
        handleLength    = 10;
        handleWidth     = 20;
        minPosition     = posX + 10;
        maxPosition     = minPosition + barLength - handleLength;

        text.setFont(font);
        text.setString(label);
        text.setCharacterSize(20);
        text.setFillColor(sf::Color::White);
        text.setPosition(posX, posY);

        sliderBar.setSize(sf::Vector2f(barLength, barWidth));
        sliderBar.setFillColor(sf::Color::White);
        sliderBar.setPosition(minPosition, posY + 40);

        sliderHandle.setSize(sf::Vector2f(handleLength, handleWidth));
        sliderHandle.setFillColor(sf::Color(128, 128, 128));
        sliderHandle.setPosition(
            maxPosition - 20, 
            posY + 40 + (barWidth - handleWidth) / 2
        );
    }

    void draw(sf::RenderWindow &window) {
        window.draw(text);
        window.draw(sliderBar);
        window.draw(sliderHandle);
    }

    void handleInput(sf::RenderWindow& window, sf::Event event) {
        if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
            if (sliderHandle.getGlobalBounds().contains(window.mapPixelToCoords(sf::Mouse::getPosition(window))))
                dragging = 1;
        }

        if (event.type == sf::Event::MouseButtonReleased && event.mouseButton.button == sf::Mouse::Left)
            dragging = 0;

        if (dragging && event.type == sf::Event::MouseMoved) {
            float mouseX = sf::Mouse::getPosition(window).x;

            if (mouseX <= minPosition) 
                mouseX = minPosition;
            else if (mouseX >= maxPosition) 
                mouseX = maxPosition;

            sliderHandle.setPosition(mouseX, sliderHandle.getPosition().y);
            curVal = (mouseX - minPosition) / (maxPosition - minPosition);
        }
    }
};

class Checkbox {
public:
    bool                    checked             = 0;
    sf::Font                font;
    sf::Text                text;
    sf::CircleShape         checkboxBox;

    Checkbox(const std::string &label, float posX, float posY) 
    {
        font.loadFromFile("Fonts/upheavtt.ttf");

        text.setFont(font);
        text.setString(label);
        text.setCharacterSize(20);
        text.setFillColor(sf::Color::White);
        text.setPosition(posX + 30, posY);

        checkboxBox.setRadius(10);
        checkboxBox.setFillColor(sf::Color::White);
        checkboxBox.setPosition(posX, posY + 5);
    }

    void draw(sf::RenderWindow &window) {
        window.draw(checkboxBox);
        window.draw(text);
        if (checked) {
            sf::CircleShape check;
            check.setRadius(6);
            check.setFillColor(sf::Color::Blue);
            check.setPosition(checkboxBox.getPosition().x + 4, checkboxBox.getPosition().y + 4);
            window.draw(check);
        }
    }

    void update(sf::RenderWindow& window)
    {
        switch (gl::curStyle)
        {
            case (CLASSIC):
                checked = (text.getString() ==  "Classic");
                break;

            case (MODERN):
                checked = (text.getString() ==  "Modern");
                break;

            case (CARTOON):
                checked = (text.getString() ==  "Cartoon");
                break;
            
            default:
                break;
        }
    }

    void handleInput(sf::RenderWindow& window, sf::Event event) {
        if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
            if (checkboxBox.getGlobalBounds().contains(window.mapPixelToCoords(sf::Mouse::getPosition(window)))) {
                if (text.getString() == "Classic") 
                    gl::curStyle = CLASSIC;
                else if (text.getString() == "Modern") 
                    gl::curStyle = MODERN;
                else
                    gl::curStyle = CARTOON;
            }
        }
    }
};

class ConfirmBox
{
public:
    bool                    popupOpen               = 0;
    sf::RectangleShape      popupBackground;    
    sf::Font                font;
    sf::Text                popupText;
    sf::RectangleShape      yesShadow;
    sf::RectangleShape      yesBox;
    sf::Text                yesButton;
    sf::RectangleShape      noShadow;
    sf::RectangleShape      noBox;
    sf::Text                noButton;

    ConfirmBox(std::string content, float width, float height, float x, float y)
    {
        font.loadFromFile("Fonts/upheavtt.ttf");

        popupBackground.setSize(sf::Vector2f(width, height));
        popupBackground.setFillColor(sf::Color(50, 50, 50, 150));
        popupBackground.setPosition(x, y);

        popupText.setString(content);
        popupText.setFont(font);
        popupText.setCharacterSize(23);
        popupText.setFillColor(sf::Color::White);
        popupText.setPosition(
            x + (width - popupText.getLocalBounds().width) / 2,
            y + 30
        );

        yesShadow.setSize(sf::Vector2f(100, 50));
        yesShadow.setFillColor(sf::Color(100, 200, 100, 20)); 
        yesShadow.setPosition(
            x + (width / 4) - (yesShadow.getSize().x / 2) + 5, 
            y + 120 + 5 
        );


        yesBox.setSize(sf::Vector2f(100, 50));
        yesBox.setFillColor(sf::Color(150, 255, 150, 100)); 
        yesBox.setPosition(
            x + (width / 4) - (yesBox.getSize().x / 2), 
            y + 120
        );


        yesButton.setString("Yes");
        yesButton.setFont(font);
        yesButton.setCharacterSize(20);
        yesButton.setFillColor(sf::Color::White);
        yesButton.setPosition(
            x + (width / 4) - yesButton.getLocalBounds().width / 2,
            y + 120 + (yesBox.getSize().y - yesButton.getLocalBounds().height) / 2 - 5 
        );


        noShadow.setSize(sf::Vector2f(100, 50));
        noShadow.setFillColor(sf::Color(200, 100, 100, 20));
        noShadow.setPosition(
            x + (3 * width / 4) - (noShadow.getSize().x / 2) + 5,
            y + 120 + 5
        );

        noBox.setSize(sf::Vector2f(100, 50));
        noBox.setFillColor(sf::Color(255, 150, 150, 100));
        noBox.setPosition(
            x + (3 * width / 4) - (noShadow.getSize().x / 2),
            y + 120
        );


        noButton.setString("No");
        noButton.setFont(font);
        noButton.setCharacterSize(20);
        noButton.setFillColor(sf::Color::White);
        noButton.setPosition(
            x + (3 * width / 4) - noButton.getLocalBounds().width / 2,
            y + 120 + (noBox.getSize().y - noButton.getLocalBounds().height) / 2 - 5 // adjust for centering
        );
    }

    void draw(sf::RenderWindow& window)
    {
        window.draw(popupBackground);
        window.draw(popupText);
        window.draw(yesShadow); // Draw the shadow first
        window.draw(yesBox);
        window.draw(yesButton);
        window.draw(noShadow); // Draw the shadow first
        window.draw(noBox);
        window.draw(noButton);
    }

    int handleInput(sf::RenderWindow& window, sf::Event event)
    {
        if (event.type == sf::Event::MouseButtonPressed) {
            if (event.mouseButton.button == sf::Mouse::Left) {
                sf::FloatRect yesBounds = yesBox.getGlobalBounds();
                sf::FloatRect noBounds = noBox.getGlobalBounds();
                
                if (yesBounds.contains(event.mouseButton.x, event.mouseButton.y)) 
                {
                    return 1;
                } 
                else if (noBounds.contains(event.mouseButton.x, event.mouseButton.y)) 
                {
                    return 2;
                }
            }
        }
        return 0;
    }
};