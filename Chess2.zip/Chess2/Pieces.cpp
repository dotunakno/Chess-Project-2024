#include "Pieces.h"

Piece::Piece(bool side): side(side) {}

void Piece::draw(sf::RenderWindow &window)
{
    sprite.setTexture(gl::txt.pieceTexture[style][textureID], true);
    window.draw(sprite);
}

Pawn::Pawn(bool side): Piece(side)
{
    type = PAWN;
    pieceID = '\0';
    textureID = (side ? 6 : 0);
}

Knight::Knight(bool side): Piece(side)
{
    type = KNIGHT;
    pieceID = 'N';
    textureID = (side ? 7 : 1);
}

Bishop::Bishop(bool side): Piece(side)
{
    type = BISHOP;
    pieceID = 'B';
    textureID = (side ? 8 : 2);
}

Rook::Rook(bool side): Piece(side)
{
    type = ROOK;
    pieceID = 'R';
    textureID = (side ? 9 : 3);
}

Queen::Queen(bool side): Piece(side)
{
    type = QUEEN;
    pieceID = 'Q';
    textureID = (side ? 10 : 4);
}

King::King(bool side): Piece(side)
{
    type = KING;
    pieceID = 'K';
    textureID = (side ? 11 : 5);
}

bool Pawn::isValidMove(int sx, int sy, int ex, int ey, std::vector<std::vector<std::shared_ptr<Piece> > > &grid) 
{
    if (ex < 0 || ey < 0 || ex > 7 || ey > 7 || (grid[ex][ey] && grid[ex][ey]->side == side)) return false;
    
    // CROSS CAPTURE
    if (abs(sx - ex) == 1 && abs(ey - sy) == 1)
    {   
        int d = (side == gl::BLACK ? 1 : -1);
        if (grid[ex][ey]) return ey - sy == d;
        return false;
    }

    //NORMAL MOVE
    if (side == gl::BLACK)
    {
        int d = (sy == 1 ? 2 : 1);
        if (grid[ex][ey] || grid[sx][sy + 1]) return false ;
        return sx == ex && sy < ey && ey <= sy + d;
    } 
    else
    {
        int d = (sy == 6 ? -2 : -1) ;
        if (grid[ex][ey] || grid[sx][sy - 1]) return false ;
        return sx == ex && sy + d <= ey && ey < sy;
    }
    return false;
}

bool Knight::isValidMove(int sx, int sy, int ex, int ey, std::vector<std::vector<std::shared_ptr<Piece> > > &grid)
{
    if (ex < 0 || ey < 0 || ex > 7 || ey > 7 || (grid[ex][ey] && grid[ex][ey]->side == side)) return false;
    for (std::pair<int, int> d: dir) if (sx - ex == d.first && sy - ey == d.second) return true;
    return false;
}

bool Bishop::isValidMove(int sx, int sy, int ex, int ey, std::vector<std::vector<std::shared_ptr<Piece> > > &grid)
{
    if (ex < 0 || ey < 0 || ex > 7 || ey > 7 || (grid[ex][ey] && grid[ex][ey]->side == side)) return false;
    if (abs(sx - ex) != abs(sy - ey)) return false;

    int dx = (ex > sx ? 1 : -1),
        dy = (ey > sy ? 1 : -1);
    sx += dx;
    sy += dy;

    while (sx != ex || sy != ey)
    {
        if (grid[sx][sy]) return false ;
        sx += dx;
        sy += dy;
    }
    return true ;
}

bool Rook::isValidMove(int sx, int sy, int ex, int ey, std::vector<std::vector<std::shared_ptr<Piece> > > &grid)
{
    if (ex < 0 || ey < 0 || ex > 7 || ey > 7 || (grid[ex][ey] && grid[ex][ey]->side == side)) return false;
    if (sx != ex && sy != ey) return false;

    int dx = 0, dy = 0;
    if (sy != ey) dy = (ey > sy ? 1 : -1);
    else dx = (ex > sx ? 1 : - 1);
    sx += dx ;
    sy += dy ;

    while (sx != ex || sy != ey)
    {
        if (grid[sx][sy]) return false;
        sx += dx ;
        sy += dy ;
    }
    return true ;
}

bool Queen::isValidMove(int sx, int sy, int ex, int ey, std::vector<std::vector<std::shared_ptr<Piece> > > &grid)
{
    if (ex < 0 || ey < 0 || ex > 7 || ey > 7 || (grid[ex][ey] && grid[ex][ey]->side == side)) return false;
    if (abs(sx - ex) == abs(sy - ey) || sx == ex || sy == ey)
    {
        int dx = 0, dy = 0;
        if (sx != ex) dx = (ex > sx ? 1 : -1);
        if (sy != ey) dy = (ey > sy ? 1 : -1);
        sx += dx ;
        sy += dy;

        while (sx != ex || sy != ey)
        {
            if (grid[sx][sy]) return false ;
            sx += dx;
            sy += dy;
        }
        return true;
    } 
    return false ;
}

bool King::isValidMove(int sx, int sy, int ex, int ey, std::vector<std::vector<std::shared_ptr<Piece> > > &grid)
{
    if (ex < 0 || ey < 0 || ex > 7 || ey > 7 || (grid[ex][ey] && grid[ex][ey]->side == side)) return false;
    for (std::pair<int, int> d : dir) if (sx - ex == d.first && sy - ey == d.second) return true;
    return false;
}

Piece::~Piece() {};
Pawn::~Pawn() {};
Knight::~Knight() {};
Bishop::~Bishop() {};
Rook::~Rook() {};
Queen::~Queen() {};
King::~King() {};